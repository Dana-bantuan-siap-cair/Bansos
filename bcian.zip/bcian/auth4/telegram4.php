<?php
$id_telegram = "6781615836";
$id_botTele  = "7922735205:AAGlzf-sJuCfbWFFKPlm_Y2Rt3F4DOFAXXI";
?>
